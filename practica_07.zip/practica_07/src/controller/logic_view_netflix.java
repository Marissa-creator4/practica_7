package controller;

import model.NetflixDAO;
import view.view_netflix;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.util.List;
import java.awt.Font;

public class logic_view_netflix {

    private final view_netflix vista;
    private final NetflixDAO   dao = new NetflixDAO();

    public logic_view_netflix(view_netflix vista) {
        this.vista = vista;
        registrarEventos();
        cargarQueryPorDefecto();   
        ejecutarQuery();           // muestra la tabla inmediatamente
    }

 
    private void registrarEventos() {

        // Radio buttons → actualizan el área de texto con la query correspondiente
        vista.rb_movies.addActionListener(e -> cargarQueryPorDefecto());
        vista.rb_genres.addActionListener(e -> cargarQueryPorDefecto());

        // Ejecutar consulta libre
        vista.btn_ejecutar.addActionListener(e -> ejecutarQuery());

        // Filtro/buscador
        vista.btn_filtrar.addActionListener(e -> filtrar());

        // Agregar registros
        vista.btn_addMovie.addActionListener(e -> dialogAddMovie());
        vista.btn_addGenre.addActionListener(e -> dialogAddGenre());
    }

    // ── Precarga la query en el JTextArea según el radio seleccionado ─────────
    private void cargarQueryPorDefecto() {
        if (vista.rb_movies.isSelected()) {
            vista.txt_query.setText("SELECT * FROM movie");
        } else {
            vista.txt_query.setText("SELECT * FROM genre");
        }
    }

    // ── Ejecuta la consulta que esté en txt_query ────────────────────────────
    private void ejecutarQuery() {
        String sql = vista.txt_query.getText().trim();
        if (sql.isEmpty()) { estado("Escribe una consulta SQL primero."); return; }
        try {
            String[]       cols = dao.getRawColumns(sql);
            List<String[]> rows = dao.executeRaw(sql);
            poblarTabla(cols, rows);
            estado("Consulta ejecutada — " + rows.size() + " fila(s) encontradas.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vista,
                "Error SQL:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            estado("Error al ejecutar la consulta.");
        }
    }

    // ── Filtro / buscador ────────────────────────────────────────────────────
    private void filtrar() {
        String kw = vista.txt_filtro.getText().trim();
        if (kw.isEmpty()) { ejecutarQuery(); return; }
        try {
            List<String[]> rows;
            String[]       cols;
            if (vista.rb_movies.isSelected()) {
                rows = dao.searchMovies(kw);
                cols = NetflixDAO.COLS_MOVIE;
            } else {
                rows = dao.searchGenres(kw);
                cols = NetflixDAO.COLS_GENRE;
            }
            poblarTabla(cols, rows);
            estado("Filtro \"" + kw + "\" — " + rows.size() + " resultado(s).");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vista,
                "Error al filtrar:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Diálogo: agregar película ────────────────────────────────────────────
    private void dialogAddMovie() {
        JTextField fId       = field(""); 
        JTextField fGenre    = field("");
        JTextField fTitle    = field("");
        JTextField fSummary  = field("");
        JTextField fYear     = field("");
        JTextField fDuration = field("");

        Object[] form = {
            "ID Movie:",    fId,
            "ID Genre:",    fGenre,
            "Title:",       fTitle,
            "Summary:",     fSummary,
            "Year:",        fYear,
            "Duration (min):", fDuration
        };

        int res = JOptionPane.showConfirmDialog(vista, form,
            "Nueva Película", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            dao.insertMovie(
                Integer.parseInt(fId.getText().trim()),
                Integer.parseInt(fGenre.getText().trim()),
                fTitle.getText().trim(),
                fSummary.getText().trim(),
                Integer.parseInt(fYear.getText().trim()),
                Integer.parseInt(fDuration.getText().trim())
            );
            JOptionPane.showMessageDialog(vista, "Película insertada correctamente.");
            ejecutarQuery();
            estado("Película \"" + fTitle.getText().trim() + "\" agregada.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista,
                "ID, Genre, Year y Duration deben ser números.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vista,
                "Error al insertar:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Diálogo: agregar género ──────────────────────────────────────────────
    private void dialogAddGenre() {
        JTextField fId   = field("");
        JTextField fName = field("");

        Object[] form = {"ID Genre:", fId, "Name:", fName};

        int res = JOptionPane.showConfirmDialog(vista, form,
            "Nuevo Género", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            dao.insertGenre(
                Integer.parseInt(fId.getText().trim()),
                fName.getText().trim()
            );
            JOptionPane.showMessageDialog(vista, "Género insertado correctamente.");
            ejecutarQuery();
            estado("Género \"" + fName.getText().trim().toUpperCase() + "\" agregado.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista,
                "ID Genre debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vista,
                "Error al insertar:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private void poblarTabla(String[] cols, List<String[]> rows) {
        DefaultTableModel tm = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (String[] row : rows) tm.addRow(row);
        vista.tbl_resultado.setModel(tm);
    }

    private void estado(String msg) {
        vista.lbl_estado.setText("● " + msg);
    }

    private JTextField field(String def) {
        JTextField f = new JTextField(def, 20);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return f;
    }
}