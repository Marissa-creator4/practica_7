package Main;

import view.view_netflix;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new view_netflix().setVisible(true));
    }
}