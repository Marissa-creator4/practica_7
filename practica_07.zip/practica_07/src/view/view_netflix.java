package view;

import controller.logic_view_netflix;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class view_netflix extends JFrame {

 
    public JRadioButton rb_movies;
    public JRadioButton rb_genres;
    public JTextArea    txt_query;
    public JButton      btn_ejecutar;
    public JTextField   txt_filtro;
    public JButton      btn_filtrar;
    public JButton      btn_addMovie;
    public JButton      btn_addGenre;
    public JTable       tbl_resultado;
    public JLabel       lbl_estado;

 
    private static final Color C_BG      = new Color(20, 20, 20);
    private static final Color C_PANEL   = new Color(30, 30, 30);
    private static final Color C_RED     = new Color(229, 9, 20);
    private static final Color C_RED_H   = new Color(255, 50, 60);
    private static final Color C_TEXT    = new Color(230, 230, 230);
    private static final Color C_MUTED   = new Color(140, 140, 140);
    private static final Color C_BORDER  = new Color(60, 60, 60);
    private static final Color C_ROW1    = new Color(35, 35, 35);
    private static final Color C_ROW2    = new Color(25, 25, 25);
    private static final Color C_HEADER  = new Color(10, 10, 10);

    public view_netflix() {
        setTitle("Netflix DB Manager");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1050, 640);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(C_BG);

        add(buildHeader(),  BorderLayout.NORTH);
        add(buildCenter(),  BorderLayout.CENTER);
        add(buildFooter(),  BorderLayout.SOUTH);

        new logic_view_netflix(this);
    }

    // ── Header ────────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 22, 12));
        p.setBackground(new Color(10, 10, 10));
        p.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, C_RED));

        JLabel logo = new JLabel("NETFLIX");
        logo.setFont(new Font("Impact", Font.PLAIN, 32));
        logo.setForeground(C_RED);

        JLabel sub = new JLabel("Database Manager");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        sub.setForeground(C_MUTED);

        p.add(logo);
        p.add(sub);
        return p;
    }

    // ── Centro: panel izquierdo + tabla ───────────────────────────────────────
    private JSplitPane buildCenter() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildLeftPanel(), buildTablePanel());
        split.setDividerLocation(300);
        split.setDividerSize(4);
        split.setBackground(C_BG);
        split.setBorder(null);
        return split;
    }

    // ── Panel izquierdo ───────────────────────────────────────────────────────
    private JPanel buildLeftPanel() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(C_PANEL);
        p.setBorder(new EmptyBorder(18, 16, 18, 16));

        // Radio buttons
        JLabel lbl1 = sectionLabel("SELECCIONAR TABLA");
        p.add(lbl1);
        p.add(Box.createVerticalStrut(8));

        rb_movies = makeRadio("🎬  Movies");
        rb_genres = makeRadio("🎭  Genres");
        ButtonGroup bg = new ButtonGroup();
        bg.add(rb_movies);
        bg.add(rb_genres);
        rb_movies.setSelected(true);
        p.add(rb_movies);
        p.add(Box.createVerticalStrut(4));
        p.add(rb_genres);
        p.add(Box.createVerticalStrut(18));
        p.add(separator());

        // Query
        p.add(sectionLabel("CONSULTA SQL"));
        p.add(Box.createVerticalStrut(8));
        txt_query = new JTextArea(5, 1);
        txt_query.setFont(new Font("Consolas", Font.PLAIN, 12));
        txt_query.setForeground(new Color(180, 230, 180));
        txt_query.setBackground(new Color(15, 15, 15));
        txt_query.setCaretColor(Color.WHITE);
        txt_query.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_BORDER),
            new EmptyBorder(6, 8, 6, 8)));
        txt_query.setLineWrap(true);
        JScrollPane sp = new JScrollPane(txt_query);
        sp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
        sp.setAlignmentX(LEFT_ALIGNMENT);
        sp.setBorder(null);
        p.add(sp);
        p.add(Box.createVerticalStrut(8));

        btn_ejecutar = makeBtn("▶  Ejecutar Consulta", C_RED);
        p.add(btn_ejecutar);
        p.add(Box.createVerticalStrut(18));
        p.add(separator());

        // Filtro
        p.add(sectionLabel("FILTRO / BUSCADOR"));
        p.add(Box.createVerticalStrut(8));
        txt_filtro = new JTextField();
        txt_filtro.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txt_filtro.setForeground(C_TEXT);
        txt_filtro.setBackground(new Color(15, 15, 15));
        txt_filtro.setCaretColor(Color.WHITE);
        txt_filtro.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_BORDER),
            new EmptyBorder(6, 8, 6, 8)));
        txt_filtro.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        txt_filtro.setAlignmentX(LEFT_ALIGNMENT);
        p.add(txt_filtro);
        p.add(Box.createVerticalStrut(8));

        btn_filtrar = makeBtn("🔍  Buscar", new Color(50, 50, 50));
        p.add(btn_filtrar);
        p.add(Box.createVerticalStrut(18));
        p.add(separator());

        // Agregar
        p.add(sectionLabel("AGREGAR REGISTRO"));
        p.add(Box.createVerticalStrut(8));
        btn_addMovie = makeBtn("＋  Nueva Película", new Color(20, 80, 20));
        btn_addGenre = makeBtn("＋  Nuevo Género",   new Color(20, 50, 90));
        p.add(btn_addMovie);
        p.add(Box.createVerticalStrut(8));
        p.add(btn_addGenre);
        p.add(Box.createVerticalGlue());

        return p;
    }

    // ── Panel tabla ───────────────────────────────────────────────────────────
    private JPanel buildTablePanel() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(C_BG);
        p.setBorder(new EmptyBorder(16, 16, 10, 16));

        JLabel lbl = new JLabel("Resultados");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(C_RED);
        p.add(lbl, BorderLayout.NORTH);

        tbl_resultado = new JTable();
        tbl_resultado.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tbl_resultado.setForeground(C_TEXT);
        tbl_resultado.setBackground(C_ROW1);
        tbl_resultado.setRowHeight(28);
        tbl_resultado.setGridColor(C_BORDER);
        tbl_resultado.setSelectionBackground(C_RED);
        tbl_resultado.setSelectionForeground(Color.WHITE);
        tbl_resultado.setShowGrid(true);

        tbl_resultado.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tbl_resultado.getTableHeader().setBackground(C_HEADER);
        tbl_resultado.getTableHeader().setForeground(C_RED);
        tbl_resultado.getTableHeader().setBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, C_RED));

        tbl_resultado.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setFont(new Font("Segoe UI", Font.PLAIN, 13));
                setBorder(new EmptyBorder(0, 10, 0, 10));
                if (sel) {
                    setBackground(C_RED);
                    setForeground(Color.WHITE);
                } else {
                    setBackground(row % 2 == 0 ? C_ROW1 : C_ROW2);
                    setForeground(C_TEXT);
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tbl_resultado);
        scroll.getViewport().setBackground(C_BG);
        scroll.setBorder(BorderFactory.createLineBorder(C_BORDER));
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Footer ────────────────────────────────────────────────────────────────
    private JPanel buildFooter() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 6));
        p.setBackground(new Color(10, 10, 10));
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, C_BORDER));
        lbl_estado = new JLabel("Listo.");
        lbl_estado.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl_estado.setForeground(C_MUTED);
        p.add(lbl_estado);
        return p;
    }

    // ── Helpers de estilo ─────────────────────────────────────────────────────
    private JButton makeBtn(String txt, Color base) {
        JButton b = new JButton(txt);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        b.setForeground(Color.WHITE);
        b.setBackground(base);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(base.brighter(), 1, true),
            new EmptyBorder(7, 14, 7, 14)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(base.brighter()); }
            public void mouseExited (java.awt.event.MouseEvent e) { b.setBackground(base); }
        });
        return b;
    }

    private JRadioButton makeRadio(String txt) {
        JRadioButton rb = new JRadioButton(txt);
        rb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rb.setForeground(C_TEXT);
        rb.setBackground(C_PANEL);
        rb.setFocusPainted(false);
        rb.setAlignmentX(LEFT_ALIGNMENT);
        return rb;
    }

    private JLabel sectionLabel(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(C_MUTED);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JSeparator separator() {
        JSeparator s = new JSeparator();
        s.setForeground(C_BORDER);
        s.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        s.setAlignmentX(LEFT_ALIGNMENT);
        return s;
    }
}