package model;

public class Genre {
    private int    id_genre;
    private String name;

    public Genre() {}
    public Genre(int id_genre, String name) {
        this.id_genre = id_genre;
        this.name     = name;
    }

    public int    getId_genre()            { return id_genre; }
    public void   setId_genre(int id)      { this.id_genre = id; }
    public String getName()                { return name; }
    public void   setName(String name)     { this.name = name; }

    @Override public String toString()     { return id_genre + " - " + name; }
}