package model;

public class Movie {
    private int    id_movie;
    private int    id_genre;
    private String title;
    private String summary;
    private int    year;
    private int    duration;

    public Movie() {}
    public Movie(int id_movie, int id_genre, String title, String summary, int year, int duration) {
        this.id_movie  = id_movie;
        this.id_genre  = id_genre;
        this.title     = title;
        this.summary   = summary;
        this.year      = year;
        this.duration  = duration;
    }

    public int    getId_movie()               { return id_movie; }
    public void   setId_movie(int id_movie)   { this.id_movie = id_movie; }
    public int    getId_genre()               { return id_genre; }
    public void   setId_genre(int id_genre)   { this.id_genre = id_genre; }
    public String getTitle()                  { return title; }
    public void   setTitle(String title)      { this.title = title; }
    public String getSummary()                { return summary; }
    public void   setSummary(String summary)  { this.summary = summary; }
    public int    getYear()                   { return year; }
    public void   setYear(int year)           { this.year = year; }
    public int    getDuration()               { return duration; }
    public void   setDuration(int duration)   { this.duration = duration; }
}