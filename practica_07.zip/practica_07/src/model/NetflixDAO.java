package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NetflixDAO {

   
    public static final String[] COLS_GENRE = {"ID Genre", "Name"};
    public static final String[] COLS_MOVIE = {"ID Movie", "ID Genre", "Title", "Summary", "Year", "Duration"};
    public static final String[] COLS_TITLE_YEAR = {"Title", "Year"};
    public static final String[] COLS_ID_DUR_YEAR = {"ID Movie", "Duration", "Year"};

   

   
    public List<String[]> getAllGenres() throws SQLException {
        return query("SELECT id_genre, name FROM genre", COLS_GENRE.length);
    }


    public List<String[]> searchGenres(String keyword) throws SQLException {
        return query("SELECT id_genre, name FROM genre WHERE name LIKE '%" + keyword + "%'", COLS_GENRE.length);
    }

    public void insertGenre(int id_genre, String name) throws SQLException {
        String sql = "INSERT INTO genre (id_genre, name) VALUES (?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id_genre);
            ps.setString(2, name.toUpperCase());
            ps.executeUpdate();
        }
    }

    // ── MOVIE queries ─────────────────────────────────────────────────────────

    /** SELECT * FROM movie */
    public List<String[]> getAllMovies() throws SQLException {
        return query("SELECT id_movie, id_genre, title, summary, year, duration FROM movie", COLS_MOVIE.length);
    }

    /** Título y año de películas publicadas después del 2010 */
    public List<String[]> getMoviesAfter2010() throws SQLException {
        return query("SELECT title, year FROM movie WHERE year > 2010", COLS_TITLE_YEAR.length);
    }

    /** Título y año de películas cuyo título contiene "The" */
    public List<String[]> getMoviesWithThe() throws SQLException {
        return query("SELECT title, year FROM movie WHERE title LIKE '%The%'", COLS_TITLE_YEAR.length);
    }

    /** Título y año ordenados por año ASC */
    public List<String[]> getMoviesOrderByYearAsc() throws SQLException {
        return query("SELECT title, year FROM movie ORDER BY year ASC", COLS_TITLE_YEAR.length);
    }

    /** id_movie, duración y año de películas > 2010, ordenadas por año DESC */
    public List<String[]> getMoviesAfter2010Desc() throws SQLException {
        return query("SELECT id_movie, duration, year FROM movie WHERE year > 2010 ORDER BY year DESC", COLS_ID_DUR_YEAR.length);
    }

    /** Busca películas cuyo título contiene la keyword */
    public List<String[]> searchMovies(String keyword) throws SQLException {
        return query(
            "SELECT id_movie, id_genre, title, summary, year, duration FROM movie WHERE title LIKE '%" + keyword + "%'",
            COLS_MOVIE.length);
    }

    /** Ejecuta una query SQL libre y devuelve sus filas como String[] */
    public List<String[]> executeRaw(String sql) throws SQLException {
        List<String[]> result = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement  st = c.createStatement();
             ResultSet  rs = st.executeQuery(sql)) {
            int cols = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                String[] row = new String[cols];
                for (int i = 0; i < cols; i++) row[i] = rs.getString(i + 1);
                result.add(row);
            }
        }
        return result;
    }

    /** Devuelve los nombres de columna de un ResultSet arbitrario */
    public String[] getRawColumns(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             Statement  st = c.createStatement();
             ResultSet  rs = st.executeQuery(sql)) {
            int cols = rs.getMetaData().getColumnCount();
            String[] names = new String[cols];
            for (int i = 0; i < cols; i++) names[i] = rs.getMetaData().getColumnLabel(i + 1);
            return names;
        }
    }

    /** INSERT INTO movie */
    public void insertMovie(int id_movie, int id_genre, String title,
                            String summary, int year, int duration) throws SQLException {
        String sql = "INSERT INTO movie (id_movie, id_genre, title, summary, year, duration) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id_movie);
            ps.setInt(2, id_genre);
            ps.setString(3, title);
            ps.setString(4, summary);
            ps.setInt(5, year);
            ps.setInt(6, duration);
            ps.executeUpdate();
        }
    }

    // ── helper interno ────────────────────────────────────────────────────────
    private List<String[]> query(String sql, int numCols) throws SQLException {
        List<String[]> rows = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement  st = c.createStatement();
             ResultSet  rs = st.executeQuery(sql)) {
            while (rs.next()) {
                String[] row = new String[numCols];
                for (int i = 0; i < numCols; i++) row[i] = rs.getString(i + 1);
                rows.add(row);
            }
        }
        return rows;
    }
}